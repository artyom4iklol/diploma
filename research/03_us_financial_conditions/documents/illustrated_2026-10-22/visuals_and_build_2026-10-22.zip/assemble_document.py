from pathlib import Path
import re,json,subprocess,copy,hashlib,os
from collections import Counter
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH,WD_TAB_ALIGNMENT,WD_TAB_LEADER
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image

W=Path(__file__).resolve().parent;R=Path(os.environ.get('DIPLOMA_RESEARCH_ROOT',W/'source/research/03_us_financial_conditions'))
OUT=W/'Diploma_Growth_at_Risk_full.docx'
REF=Path(os.environ.get('DIPLOMA_REFERENCE_DOCX',W.parent/'diploma/research/02_chip_trade/documents/diploma_full.docx'))
manifest=json.loads((W/'visual_manifest.json').read_text());by={x['number']:x for x in manifest}
sections={n:(R/f'manuscript/sections/{n}.md').read_text() for n in ['introduction','chapter-1','chapter-2','chapter-3','conclusion','references','appendices']}
table_original=[]
for section,s in sections.items():
    for x in re.finditer(r'^Таблица ([А-ЯA-Z0-9]+\.\d+)\. (.+)$',s,re.M):table_original.append({'number':x[1],'title':x[2],'section':section})
assert len(table_original)==43,len(table_original)

def block(key):return '\n\n[[FIG:'+key+']]\n\n'
def before(s,needle,keys):
    assert s.count(needle)==1,(needle,s.count(needle));return s.replace(needle,''.join(block(k)for k in keys)+needle,1)
def after_paragraph(s,needle,keys):
    start=s.index(needle);end=s.find('\n\n',start)
    assert end>0,needle
    return s[:end]+''.join(block(k)for k in keys)+s[end:]

# Retain original source and explanations; replace image placeholders with reviewed assets.
for n in ['chapter-2','chapter-3']:
    s=sections[n]
    s=re.sub(r'Рисунок ([23]\.\d+)\. [^\n]+',lambda m:'[[FIG:'+m[1]+']]',s)
    s=re.sub(r'!\[[^\]]*\]\([^\n]+\)\s*','',s)
    s=re.sub(r'```mermaid\n.*?```\s*','',s,flags=re.S)
    sections[n]=s
s=sections['chapter-1'];s=before(s,'## 1.3.',['1.1']);s+=block('1.2');sections['chapter-1']=s
s=sections['chapter-2']
s=before(s,'## 2.2.',['2.6','2.7'])
s=before(s,'## 2.3.',['2.15'])
s=after_paragraph(s,'Таким образом, последовательное улучшение',[]) if 'Таким образом, последовательное улучшение' in s else s
s=before(s,'Таблица 2.3.',['2.8','2.9'])
s=before(s,'[[FIG:2.1]]',['2.10','2.13'])
s=before(s,'Таблица 2.5.',['2.12'])
s=before(s,'Таблица 2.6.',['2.11'])
s=before(s,'Таблица 2.7.',['2.16'])
s=before(s,'[[FIG:2.3]]',['2.14'])
s=before(s,'Таблица 2.8.',['2.17','2.18','2.19'])
sections['chapter-2']=s
s=sections['chapter-3'];s=before(s,'Таблица 3.4.',['3.2','3.3']);s+=block('3.4');sections['chapter-3']=s
s=sections['appendices'];s=before(s,'## Приложение В.',['Б.1','Б.2']);sections['appendices']=s

# Number figures consecutively in actual reading order. Update old references atomically.
order=re.findall(r'\[\[FIG:([^\]]+)\]\]','\n'.join(sections.values()));assert len(order)==27 and len(set(order))==27
counts=Counter();mapping={}
for key in order:
    chapter=key.split('.')[0];counts[chapter]+=1;mapping[key]=chapter+'.'+str(counts[chapter])
for key,new in mapping.items():by[key]['final_number']=new

def fig_md(key):
    x=by[key];num=x['final_number'];caption='Рисунок '+num+' — '+x['title']
    # Sources of original figures are already present in the surrounding manuscript.
    extra='' if x['place']=='existing' else '\n\nИсточник: '+('составлено автором. 'if key in ['1.1','1.2','2.6','3.4']else'расчёты автора. ')+x['note']
    return f'На рисунке {num} представлено сопоставление, дополняющее изложенный анализ.\n\n![{x["title"]}]({x["file"]})\n\n{caption}{extra}'

combined='\n\n'.join(sections.values())
combined=re.sub(r'рисун(?:ок|к[а-я]+) 2\.1–2\.5','@@FIVEFIGS@@',combined,flags=re.I)
combined=re.sub(r'((?:[Рр]исун(?:ок|к[а-я]+)|[Рр]ис\.)\s+)([123Б]\.\d+)',lambda m:m[1]+'@@REF'+m[2]+'@@',combined)
combined=re.sub(r'@@REF([^@]+)@@',lambda m:mapping.get(m[1],m[1]),combined)
combined=combined.replace('@@FIVEFIGS@@','рисунки '+', '.join(mapping['2.'+str(i)]for i in range(1,6)))
combined=re.sub(r'\[\[FIG:([^\]]+)\]\]',lambda m:fig_md(m[1]),combined)
# Make explanatory lead-ins specific and remove generic rendering scaffolding.
leads={
 '1.1':'Каналы международной передачи финансовых условий обобщены на рисунке {n}.',
 '1.2':'Последовательность проверки дополнительной прогнозной информативности представлена на рисунке {n}.',
 '2.6':'Календарное разделение входной информации и последующей оценки показано на рисунке {n}.',
 '2.7':'Динамика предикторов в исторических информационных наборах представлена на рисунке {n}.',
 '2.15':'Изменение числа допустимых обучающих строк показано на рисунке {n}.',
 '2.8':'Сопоставление всех восьми моделей с HIST представлено на рисунке {n}.',
 '2.9':'Различия частот нарушений относительно номинального уровня показаны на рисунке {n}.',
 '2.10':'Вклад двух типов ошибок в среднюю потерю сопоставлен на рисунке {n}.',
 '2.13':'Рисунок {n} показывает, насколько часто американские расширения выигрывают на отдельных датах.',
 '2.12':'Концентрация суммарного выигрыша ANFCI на отдельных датах показана на рисунке {n}.',
 '2.11':'Рисунок {n} сопоставляет качество при исторических и поздних версиях американских индексов.',
 '2.16':'Изменение охвата недель при одной исторической версии иллюстрирует рисунок {n}.',
 '2.14':'Положение текущего лагового роста относительно диапазона обучения показано на рисунке {n}.',
 '2.17':'Сравнение четырёх календарных групп неперекрывающихся целей приведено на рисунке {n}.',
 '2.18':'Результаты исключения блоков соседних дат показаны на рисунке {n}.',
 '2.19':'На рисунке {n} представлены оценки неопределённости для отдельной процедуры со скользящим окном.',
 '3.2':'Реконструированный выпуск января 2021 года и чувствительность его прогнозов показаны на рисунке {n}.',
 '3.3':'Реконструированный выпуск января 2025 года представлен на рисунке {n}.',
 '3.4':'Последовательность проверки новой прогнозной процедуры обобщена на рисунке {n}.',
 'Б.1':'Различия относительных потерь по историческим отрезкам представлены на рисунке {n}.',
 'Б.2':'Проверка ранжирования на общих исходных датах показана на рисунке {n}.'}
for key,x in by.items():
    n=x['final_number'];old=f'На рисунке {n} представлено сопоставление, дополняющее изложенный анализ.'
    combined=combined.replace(old,leads.get(key,'Результаты сопоставления представлены на рисунке {n}.').format(n=n))

# Preserve all 14 numbered equations as native Word mathematics.
formula_titles=['Годовой логарифмический рост','Определение Growth at Risk','Линейный прогноз условного квантиля','Квантильная потеря','Лаговый рост в исторической версии ВВП','Целевой темп роста','Расширенная квантильная модель','Задача оценивания квантильной регрессии','Доступность обучающих целей','Исторический эмпирический квантиль HIST','Средняя квантильная потеря','Относительная потеря','Частота нарушений','Ограничение текущего роста обучающим диапазоном']
formula_nums=re.findall(r'\\tag\{([^}]+)\}',combined);assert len(formula_nums)==14
combined=re.sub(r'\\tag\{([^}]+)\}',lambda m:r'\qquad\text{('+m[1]+')}',combined)

# Full inventory: the user can see every visual, its location, and its numeric source.
inventory='\n\n## Приложение Д. Перечень графических и табличных материалов\n\n'
inventory+='Перечень фиксирует состав иллюстраций, таблиц и нумерованных формул диплома. Числовые рисунки строятся по сохранённым результатам; схемы обобщают теоретические связи и предлагаемые действия.\n\n'
inventory+='Таблица Д.1. Рисунки, схемы и источники данных\n\n| № | Содержание | Данные и основание |\n|---|---|---|\n'
for key in order:
    x=by[key];inventory+=f'| {x["final_number"]} | {x["title"]} | {x["data"]} |\n'
inventory+='\nТаблица Д.2. Полный перечень таблиц диплома\n\n| № | Название |\n|---|---|\n'
for x in table_original:inventory+=f'| {x["number"]} | {x["title"]} |\n'
for n,t in [('Д.1','Рисунки, схемы и источники данных'),('Д.2','Полный перечень таблиц диплома'),('Д.3','Нумерованные формулы исследования')]:inventory+=f'| {n} | {t} |\n'
inventory+='\nТаблица Д.3. Нумерованные формулы исследования\n\n| № | Назначение |\n|---|---|\n'
for n,t in zip(formula_nums,formula_titles):inventory+=f'| {n} | {t} |\n'
combined+=inventory
combined=combined.replace('четыре приложения','пять приложений').replace('четырёх приложений','пяти приложений')
combined=re.sub(r'<a\s+id="[^"]+"\s*></a>','',combined)
# Bibliographic URLs remain plain text, with no live links in the final file.
combined=re.sub(r'(?<!!)\[([^\]]+)\]\((https?://[^\s)]+)\)',lambda m:m[1]+' (URL: '+m[2]+')',combined)
combined=re.sub(r'^Таблица ([А-ЯA-Z0-9]+\.\d+)\. ',r'Таблица \1 — ',combined,flags=re.M)
(W/'assembled_full.md').write_text(combined)
(W/'visual_manifest_final.json').write_text(json.dumps([by[k]for k in order],ensure_ascii=False,indent=2)+'\n')
subprocess.run(['pandoc',str(W/'assembled_full.md'),'-f','markdown-implicit_figures+tex_math_dollars+footnotes','--reference-doc',str(REF),'-o',str(W/'base.docx')],check=True)
d=Document(W/'base.docx')
black=RGBColor(0,0,0)
for st in d.styles:
    if st.type in [1,2]:
        st.font.color.rgb=black
        if st.type==1:st.font.name='Times New Roman'
normal=d.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(12)
normal.paragraph_format.line_spacing=1.5;normal.paragraph_format.first_line_indent=Cm(1.25);normal.paragraph_format.space_before=Pt(0);normal.paragraph_format.space_after=Pt(0)
for nm,sz in [('Title',14),('Heading 1',14),('Heading 2',13),('Heading 3',12),('Heading 4',12)]:
    st=d.styles[nm];st.font.size=Pt(sz);st.font.bold=True;pf=st.paragraph_format;pf.first_line_indent=Cm(0);pf.space_before=Pt(14 if nm!='Heading 1'else 0);pf.space_after=Pt(10);pf.line_spacing=1.3;pf.keep_with_next=True;pf.keep_together=True
    if nm=='Heading 1':pf.page_break_before=True
for sec in d.sections:
    sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=Cm(2.5);sec.right_margin=Cm(2);sec.top_margin=Cm(2);sec.bottom_margin=Cm(2);sec.footer_distance=Cm(1);sec.different_first_page_header_footer=True
    for f in [sec.footer,sec.first_page_footer]:
        for p in list(f.paragraphs):p.clear()
    p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');r=OxmlElement('w:r');t=OxmlElement('w:t');t.text='1';r.append(t);field.append(r);p._p.append(field)

def setfont(p,size=12):
    for run in p.runs:run.font.name='Times New Roman';run.font.size=Pt(size);run.font.color.rgb=black

# Native Word tables: explicit widths, repeating headers, visible light borders.
for ti,table in enumerate(d.tables):
    table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=False;cols=len(table.columns)
    tw=table._tbl.tblPr.find(qn('w:tblW'));tw.set(qn('w:type'),'dxa');tw.set(qn('w:w'),str(int(Cm(16.5).twips)))
    lengths=[]
    for j in range(cols):
        texts=[c.cells[j].text for c in table.rows]
        lengths.append(min(80,max(5,np_percentile([len(t)for t in texts],70)))) if False else None
        lengths.append(min(65,max(5,sorted(len(t)for t in texts)[int((len(texts)-1)*.70)])))
    headers=[c.text for c in table.rows[0].cells]
    short_headers={'Число оцениваемых прогнозов':'Число прогнозов','Наименьшая потеря среди пяти исходных моделей':'Лучшая из пяти моделей','Публикация оценочной версии':'Дата оценочной версии','Частота и источник исторических значений':'Частота и исторический источник','Подставленное значение':'Значение после ограничения','Разность':'Разн.','p Holm(20)':'p Holm'}
    for cell in table.rows[0].cells:
        if cell.text in short_headers:cell.text=short_headers[cell.text]
    # Wide numeric matrices need room for model/configuration names and intervals.
    if cols>=6:
        weights=[2.0 if j==0 else 1.0 for j in range(cols)]
        for j,h in enumerate(headers):
            if any(k in h.lower()for k in ['модель','сравнение','конфигурац','интервал']):weights[j]=2.1
    else:weights=[max(1,l**.65)for l in lengths]
    widths=[16.5*v/sum(weights)for v in weights]
    if cols==8 and headers[0]=='h':
        widths=[.6,2.1,1.5,1.9,2,1.9,1.9,2.6]
        table.rows[0].cells[-1].text='Исключения с выигрышем'
    if cols==7 and headers[0]=='h':widths=[.6,2,5.5,.7,1.6,2.5,3.6]
    for c,w in zip(table.columns,widths):c.width=Cm(w)
    borders=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        n=OxmlElement('w:'+side);n.set(qn('w:val'),'single');n.set(qn('w:sz'),'4');n.set(qn('w:color'),'D9D9D9');borders.append(n)
    pr=table._tbl.tblPr;old=pr.find(qn('w:tblBorders'))
    if old is not None:pr.remove(old)
    pr.append(borders)
    for ri,row in enumerate(table.rows):
        trpr=row._tr.get_or_add_trPr()
        if ri==0:
            repeat=OxmlElement('w:tblHeader');trpr.append(repeat)
        # Permit long narrative rows to break, keep numeric records intact.
        if max(len(c.text)for c in row.cells)<450:
            ns=OxmlElement('w:cantSplit');trpr.append(ns)
        for j,cell in enumerate(row.cells):
            cell.width=Cm(widths[j]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cp=cell._tc.get_or_add_tcPr();shade=cp.find(qn('w:shd'))
            if shade is not None:cp.remove(shade)
            if ri==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'EEEEEE');cp.append(sh)
            mar=OxmlElement('w:tcMar')
            for side,val in [('top','65'),('bottom','65'),('left','80'),('right','80')]:
                n=OxmlElement('w:'+side);n.set(qn('w:w'),val);n.set(qn('w:type'),'dxa');mar.append(n)
            cp.append(mar)
            for p in cell.paragraphs:
                p.style=d.styles['Normal']
                p.paragraph_format.first_line_indent=Cm(0);p.paragraph_format.line_spacing=1.1;p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(1);p.paragraph_format.keep_with_next=False;p.paragraph_format.widow_control=True
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 or cols<=3 else WD_ALIGN_PARAGRAPH.CENTER
                setfont(p,9 if cols>=7 else 10 if cols>=4 else 10.5)
                if ri==0:
                    for run in p.runs:run.bold=True

for p in d.paragraphs:
    pf=p.paragraph_format;text=p.text
    if p.style.name=='Normal' or p.style.name=='Body Text':
        p.style=d.styles['Normal'];pf.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY;pf.widow_control=True;pf.keep_with_next=False
    if p.style.name.startswith('Heading'):
        pf.alignment=WD_ALIGN_PARAGRAPH.LEFT
        if p.style.name=='Heading 1':pf.alignment=WD_ALIGN_PARAGRAPH.CENTER
    if text.startswith('Таблица '):
        p.style='Caption';pf.first_line_indent=Cm(0);pf.alignment=WD_ALIGN_PARAGRAPH.LEFT;pf.line_spacing=1.1;pf.space_before=Pt(7);pf.space_after=Pt(5);pf.keep_with_next=True;pf.keep_together=True;setfont(p,11)
    if re.match(r'^Рисунок [0-9А-Я]+\.\d+ — ',text):
        p.style='Caption';pf.first_line_indent=Cm(0);pf.alignment=WD_ALIGN_PARAGRAPH.CENTER;pf.line_spacing=1.1;pf.space_before=Pt(3);pf.space_after=Pt(4);pf.keep_with_next=True;pf.keep_together=True;setfont(p,11)
    if text.startswith(('Источник:','Примечание.')):
        pf.first_line_indent=Cm(0);pf.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY;pf.line_spacing=1.1;pf.space_before=Pt(2);pf.space_after=Pt(6);pf.keep_with_next=False;setfont(p,10)
    if p._p.findall('.//'+qn('w:drawing')):
        pf.first_line_indent=Cm(0);pf.alignment=WD_ALIGN_PARAGRAPH.CENTER;pf.line_spacing=1;pf.space_before=Pt(6);pf.space_after=Pt(2);pf.keep_with_next=True;pf.keep_together=True
    # Remove underline/color remnants from imported hyperlink runs.
    for link in list(p._p.findall('.//'+qn('w:hyperlink'))):
        parent=link.getparent();i=parent.index(link)
        for ch in list(link):parent.insert(i,ch);i+=1
        parent.remove(link)

for shape in d.inline_shapes:
    ratio=shape.height/shape.width;shape.width=Cm(16.4);shape.height=int(shape.width*ratio)
    if shape.height>Cm(18):shape.height=Cm(18);shape.width=int(shape.height/ratio)
    dp=shape._inline.docPr
    if not dp.get('descr'):dp.set('descr',dp.get('name','Рисунок диплома'))

# Plain, nonlinked contents and simple cover in the same academic style.
headings=[]
for p in d.paragraphs:
    if p.style.name in ['Heading 1','Heading 2']:
        headings.append({'text':p.text,'level':0 if p.style.name=='Heading 1'else 1})
anchor=d.element.body[0]
def insert_front(text,style='Normal',align=WD_ALIGN_PARAGRAPH.CENTER,sz=12):
    n=OxmlElement('w:p');anchor.addprevious(n)
    from docx.text.paragraph import Paragraph
    p=Paragraph(n,d._body);p.style=style;p.alignment=align;pf=p.paragraph_format;pf.first_line_indent=Cm(0);pf.keep_with_next=False;pf.line_spacing=1.3;pf.space_after=Pt(12);p.add_run(text);setfont(p,sz);return p
insert_front('Национальный исследовательский университет\n«Высшая школа экономики»',sz=14)
p=insert_front('Выпускная квалификационная работа',sz=14);p.paragraph_format.space_before=Pt(70)
p=insert_front('Финансовые условия США в прогнозировании\nрисков роста еврозоны','Title',sz=16)
p=insert_front('Москва\n2026',sz=12);p.paragraph_format.space_before=Pt(100)
p=insert_front('Оглавление','Title',sz=14);p.paragraph_format.page_break_before=True
for h in headings:
    label=h['text']
    if label.startswith('Глава 2.'):label=label.replace('информативности финансовых','информативности\nфинансовых')
    p=insert_front(label+'\t000',align=WD_ALIGN_PARAGRAPH.LEFT,sz=11)
    pf=p.paragraph_format;pf.left_indent=Cm(.45 if h['level']else 0);pf.right_indent=Cm(.6);pf.line_spacing=1.0;pf.space_after=Pt(3);pf.keep_together=True;pf.tab_stops.add_tab_stop(Cm(16.2),WD_TAB_ALIGNMENT.RIGHT,WD_TAB_LEADER.DOTS)
    if not h['level']:
        for run in p.runs:run.bold=True

# Ensure every source hyperlink, including those in tables and footnotes, is plain.
for root in [d.element]+[p.element for p in d.part.related_parts.values()if hasattr(p,'element')and str(p.partname).endswith('footnotes.xml')]:
    for link in list(root.findall('.//'+qn('w:hyperlink'))):
        par=link.getparent();i=par.index(link)
        for ch in list(link):par.insert(i,ch);i+=1
        par.remove(link)
# Footnote markers attach directly to the preceding word and cannot form an isolated line.
for p in d.element.findall('.//'+qn('w:p')):
    for ref in p.findall('.//'+qn('w:footnoteReference')):
        prior=[]
        for n in p.iter():
            if n is ref:break
            if n.tag==qn('w:t'):prior.append(n)
        if prior and (prior[-1].text or '').endswith(' '):prior[-1].text=prior[-1].text.rstrip(' ')
d.core_properties.title='Финансовые условия США в прогнозировании рисков роста еврозоны';d.core_properties.subject='Выпускная квалификационная работа';d.core_properties.author='';d.core_properties.comments=''
d.save(OUT)
(W/'toc_headings.json').write_text(json.dumps(headings,ensure_ascii=False,indent=2))
from zipfile import ZipFile
with ZipFile(OUT)as z:
    from lxml import etree
    root=etree.fromstring(z.read('word/document.xml'));notes=z.read('word/footnotes.xml')if 'word/footnotes.xml'in z.namelist()else b''
    audit={'figures':len(d.inline_shapes),'tables':len(d.tables),'original_tables':43,'inventory_tables':3,'numbered_formulas':14,'native_math_elements':len(root.findall('.//'+qn('m:oMath'))),'footnote_references':len(root.findall('.//'+qn('w:footnoteReference'))),'hyperlinks':len(root.findall('.//'+qn('w:hyperlink'))),'source_sections':list(sections),'figure_mapping':mapping}
assert audit['figures']==27 and audit['tables']==46,audit
(W/'document_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(json.dumps(audit,ensure_ascii=False))
