from pathlib import Path
import argparse,json,re
import fitz
from docx import Document
W=Path(__file__).resolve().parent
def norm(s):return re.sub(r'\s+',' ',s).strip()
def run(check=False):
    d=Document(W/'Diploma_Growth_at_Risk_full.docx');pdf=fitz.open(W/('render_delivery'if check else'render4')/'Diploma_Growth_at_Risk_full.pdf')
    pages=[norm(p.get_text())for p in pdf];headings=json.loads((W/'toc_headings.json').read_text());found={}
    for h in headings:
        t=h['text']
        if t=='Приложения':hits=[i+1 for i,p in enumerate(pdf)if i>=2 and t in [x.strip()for x in p.get_text().splitlines()]]
        else:hits=[i+1 for i,p in enumerate(pages)if i>=2 and norm(t)in p]
        assert hits,t
        found[t]=hits[0]
    changed=[]
    canonical={norm(k):k for k in found}
    for p in d.paragraphs:
        if '\t'not in p.text:continue
        text,old=p.text.rsplit('\t',1)
        key=canonical.get(norm(text))
        if key is None:continue
        if old!=str(found[key]):changed.append((text,old,found[key]))
        if not check:
            assert len(p.runs)==1,(text,len(p.runs));p.runs[0].text=text+'\t'+str(found[key])
    if check:assert not changed,changed
    else:d.save(W/'Diploma_Growth_at_Risk_full.docx')
    (W/'toc_pages.json').write_text(json.dumps(found,ensure_ascii=False,indent=2))
    print(json.dumps({'pages':len(pdf),'toc_entries':len(found),'changed':len(changed),'verified':check},ensure_ascii=False))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--check',action='store_true');run(a.parse_args().check)
