from pathlib import Path
import json, hashlib, textwrap, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from matplotlib import font_manager, colors, patches
from matplotlib.ticker import FuncFormatter

W=Path(__file__).resolve().parent
R=Path(os.environ.get('DIPLOMA_RESEARCH_ROOT',W/'source/research/03_us_financial_conditions'))
O=W/'figures'; O.mkdir(exist_ok=True)
for folder in [W/'fonts',W.parent/'figure_review/fonts']:
    for p in folder.glob('*.otf'):font_manager.fontManager.addfont(str(p))
BLUE='#0B2F73'; RED='#E31B2D'; INK='#203047'; GRAY='#8795A8'; TEAL='#338C86'; PALE='#EDF1F7'
plt.rcParams.update({'font.family':'HSE Sans','font.size':9.5,'text.color':INK,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False,'axes.grid':False,'svg.fonttype':'path','savefig.facecolor':'white','figure.facecolor':'white'})
C={'HIST':INK,'AR':'#A6AFBA','AR_ESI':TEAL,'AR_ESI_NFCI':BLUE,'AR_ESI_ANFCI':RED,'AR_ESI_EQ':'#70829A','AR_ESI_EQ_NFCI':BLUE,'AR_ESI_EQ_ANFCI':RED}
MODS=['HIST','AR','AR_ESI','AR_ESI_NFCI','AR_ESI_ANFCI']
ALL=MODS+['AR_ESI_EQ','AR_ESI_EQ_NFCI','AR_ESI_EQ_ANFCI']
N={'HIST':'HIST','AR':'AR','AR_ESI':'AR + ESI','AR_ESI_NFCI':'+ NFCI','AR_ESI_ANFCI':'+ ANFCI','AR_ESI_EQ':'AR + ESI + EQ','AR_ESI_EQ_NFCI':'+ EQ + NFCI','AR_ESI_EQ_ANFCI':'+ EQ + ANFCI'}
NUM=FuncFormatter(lambda x,pos:f'{x:g}'.replace('.',','))
f=pd.read_csv(R/'revision25/results/forecasts.csv')
b=f[(f.variant=='expanding')&(f.config=='Q_raw')].copy()
e=pd.read_csv(R/'revision30/results/equity_forecasts.csv')
scores=pd.read_csv(R/'revision25/results/scores.csv')
es=pd.read_csv(R/'revision30/results/equity_scores.csv')
manifest=[]

def save(fig,key,title,data,place,note='',values=None):
    name='figure_'+key.replace('.','_')
    fig.savefig(O/(name+'.png'),dpi=360,bbox_inches='tight',pad_inches=.08)
    with Image.open(O/(name+'.png')) as check:check.load()
    fig.savefig(O/(name+'.svg'),bbox_inches='tight',pad_inches=.08)
    plt.close(fig)
    item={'number':key,'title':title,'file':str(O/(name+'.png')),'data':data,'place':place,'note':note,'sha256':hashlib.sha256((O/(name+'.png')).read_bytes()).hexdigest()}
    if values is not None:
        vals=np.asarray(values,dtype=float).ravel();assert np.isfinite(vals).all(),key
        item.update(numeric_values=len(vals),values_sha256=hashlib.sha256(vals.astype('<f8').tobytes()).hexdigest())
    manifest.append(item)

def dates(s):return pd.PeriodIndex(s,freq='Q').to_timestamp()
def style(ax,axis='y'):
    ax.grid(axis=axis,color='#D9E0E9',lw=.6,zorder=0);ax.tick_params(length=0,pad=5)
    ax.xaxis.set_major_formatter(NUM) if axis=='x' else ax.yaxis.set_major_formatter(NUM)
def panel(ax,t):ax.text(0,1.035,t,transform=ax.transAxes,fontsize=10,weight='bold',ha='left')
def ticks(ax,d,step=12):
    ix=list(range(0,len(d),step));ax.set_xticks([d[i] for i in ix],[str(pd.Timestamp(d[i]).year) for i in ix])
def legend(fig,ax,ncol=3):
    h,l=ax.get_legend_handles_labels();fig.legend(h,l,loc='upper center',bbox_to_anchor=(.5,1.0),ncol=ncol,frameon=False,fontsize=9)
def pair(height=3.7,left=.15):
    fig,axs=plt.subplots(1,2,figsize=(7.0,height));fig.subplots_adjust(left=left,right=.98,top=.86,bottom=.17,wspace=.35);return fig,axs
def box(ax,x,y,w,h,t,fill=PALE,color=BLUE,fs=10):
    ax.add_patch(patches.FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.01,rounding_size=.015',facecolor=fill,edgecolor=color,lw=.9));ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,linespacing=1.35,color=INK)
def arrow(ax,a,b,label=None):
    ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',color=GRAY,lw=1.1,shrinkA=2,shrinkB=2))
    if label:ax.text((a[0]+b[0])/2+.015,(a[1]+b[1])/2,label,fontsize=9,ha='left',va='center')

# Conceptual figures contain no estimated or fabricated quantitative values.
fig,ax=plt.subplots(figsize=(7,4.7));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
box(ax,.24,.82,.52,.13,'Изменение финансовых условий США')
for x,t in [(.02,'Долларовое\nфинансирование'),(.35,'Глобальные банки\nи фонды'),(.68,'Переоценка риска\nи стоимости активов')]:
    box(ax,x,.53,.30,.16,t,fs=9.5);arrow(ax,(.50,.82),(x+.15,.69))
box(ax,.19,.25,.62,.15,'Финансирование и балансы в еврозоне\nКредит, инвестиции, потребление');
for x in [.17,.50,.83]:arrow(ax,(x,.53),(.50,.40))
box(ax,.24,.02,.52,.13,'Распределение будущего роста ВВП');arrow(ax,(.50,.25),(.50,.15))
save(fig,'1.1','Каналы международной передачи финансовых условий США','Глава 1, § 1.1–1.2; источники [1–19]','c1:1.2','Схема теоретических связей; причинные эффекты в работе не оценивались.')
fig,ax=plt.subplots(figsize=(7,3.6));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
for x,y,t in [(.03,.69,'Исторически доступные\nВВП, ESI, NFCI / ANFCI'),(.55,.69,'Квантильная регрессия\nи простые ориентиры'),(.55,.25,'Прогноз 10-го процентиля\nна 1 и 4 квартала'),(.03,.25,'Последующая проверка\nпотерь и нарушений')]:box(ax,x,y,.42,.21,t,fs=10)
arrow(ax,(.45,.80),(.55,.80));arrow(ax,(.76,.69),(.76,.46));arrow(ax,(.55,.35),(.45,.35));arrow(ax,(.24,.46),(.24,.69))
save(fig,'1.2','Логика проверки прогнозной информативности в подходе Growth at Risk','Глава 1, § 1.3; формулы (1.1)–(1.3)','c1:end','Сопоставление прогнозов не идентифицирует международный причинный канал.')

# Existing five figures rebuilt in the same typography and palette as the earlier thesis.
fig,axs=plt.subplots(2,2,figsize=(7,5.3));fig.subplots_adjust(left=.10,right=.98,top=.90,bottom=.10,hspace=.62,wspace=.35)
for i,h in enumerate([1,4]):
    z=b[b.h==h].pivot(index='origin',columns='model',values='loss').sort_index();dt=dates(z.index)
    for j,bm in enumerate(['AR_ESI','HIST']):
        ax=axs[i,j]
        for m in MODS[-2:]:ax.plot(dt,(z[bm]-z[m]).cumsum(),color=C[m],lw=1.5,label=m.split('_')[-1])
        ax.axhline(0,color=GRAY,lw=.8);ax.axvline(pd.Timestamp('2020-10-01'),color=GRAY,ls=':',lw=.9);panel(ax,f'h = {h}; '+N[bm]);ticks(ax,dt);style(ax)
        if j==0:ax.set_ylabel('Сумма разностей потерь')
legend(fig,axs[0,0],2)
save(fig,'2.1','Накопленные разности потерь американских расширений и ориентиров','revision25/results/forecasts.csv','existing','Линия выше нуля означает меньшие потери американской модели. Вертикаль — 2020Q4. Это не денежный выигрыш.')
fig,axs=plt.subplots(2,2,figsize=(7,5.5));fig.subplots_adjust(left=.10,right=.98,top=.86,bottom=.10,hspace=.63,wspace=.33)
for i,h in enumerate([1,4]):
    for j,start in enumerate([None,'2022Q1']):
        ax=axs[i,j];z=b[b.h==h];z=z if start is None else z[z.origin>=start];a=z[z.model=='HIST'];ax.plot(dates(a.origin),a.actual,color='black',lw=1.3,label='Факт')
        for m in ['HIST','AR_ESI','AR_ESI_NFCI','AR_ESI_ANFCI']:
            a=z[z.model==m];ax.plot(dates(a.origin),a.forecast,color=C[m],lw=1.0,ls='--' if m=='HIST' else '-',label=N[m])
        dt=dates(z[z.model=='HIST'].origin);ticks(ax,dt,12 if start is None else 4);panel(ax,f'h = {h}; '+('2011–2025' if start is None else 'с 2022 года'));style(ax)
        if j==0:ax.set_ylabel('Годовой лог. рост, %')
legend(fig,axs[0,0],3)
save(fig,'2.2','Фактический рост и прогнозы нижнего квантиля','revision25/results/forecasts.csv','existing','По оси X — исходный квартал; факт относится к будущей цели. Справа другой период и масштаб Y. Линии не являются доверительными интервалами.')
fig,axs=pair(3.8,.24);vals=[]
cases=[('Исходная','Q_raw',[], 'o',-.18),('Без 2020Q4','Q_raw',['2020Q4'],'s',0),('Ограничение роста','Q_clip_g',[],'D',.18)]
for ax,h in zip(axs,[1,4]):
    for label,cfg,omit,mk,off in cases:
        z=f[(f.variant=='expanding')&(f.config==cfg)&(f.h==h)&~f.origin.isin(omit)].groupby('model').loss.mean()
        for i,m in enumerate(MODS[2:]):v=z[m]/z.HIST;vals.append(v);ax.scatter(v,i+off,s=43,color=C[m],marker=mk,zorder=3)
    ax.axvline(1,color=GRAY,ls='--');ax.set_yticks(range(3),[N[m] for m in MODS[2:]] if h==1 else ['']*3);ax.set_ylim(2.6,-.6);ax.set_xlabel('Потеря / HIST');panel(ax,f'h = {h}');style(ax,'x')
fig.legend(handles=[plt.Line2D([],[],color=INK,ls='',marker=m,label=l) for l,_,_,m,_ in cases],loc='upper center',ncol=3,frameon=False,fontsize=8.5)
save(fig,'2.3','Относительное качество после диагностики экстремального роста','revision25/results/forecasts.csv','existing','Каждая оценка нормирована на HIST на тех же датах. Ограничение роста — ретроспективная диагностика.',vals)
fig,axs=plt.subplots(2,1,figsize=(7,6.3));fig.subplots_adjust(left=.27,right=.95,top=.92,bottom=.12,hspace=.55)
rows=[(v,c)for v in ['expanding','rolling52']for c in ['Q_raw','M2_raw','Q_clip_g','M2_clip_g']];matrices=[]
for ax,h in zip(axs,[1,4]):
    mat=[]
    for v,c in rows:
        z=scores[(scores.h==h)&(scores.variant==v)&(scores.config==c)].set_index('model').mean_loss;mat.append([z[m]/z.HIST for m in MODS])
    mat=np.array(mat);matrices.extend(mat.ravel());norm=colors.TwoSlopeNorm(vmin=.85,vcenter=1,vmax=2.7);im=ax.imshow(mat,cmap=colors.LinearSegmentedColormap.from_list('hse',[BLUE,'#FFFFFF',RED]),norm=norm,aspect='auto');ax.set_yticks(range(8),[('Расш.'if v=='expanding'else'52 кв.')+' / '+c.replace('_raw','').replace('_clip_g',' + огр.')for v,c in rows],fontsize=9);ax.set_xticks(range(5),[N[m]for m in MODS],fontsize=9);ax.xaxis.tick_top();ax.tick_params(length=0);ax.text(-.50,1.04,f'h = {h}',transform=ax.transAxes,fontsize=10,weight='bold')
    for i,j in np.ndindex(mat.shape):ax.text(j,i,f'{mat[i,j]:.2f}'.replace('.',','),ha='center',va='center',fontsize=9,color='white'if mat[i,j]>2.0 else INK)
cax=fig.add_axes([.32,.045,.56,.016]);cb=fig.colorbar(im,cax=cax,orientation='horizontal',ticks=[.9,1,1.5,2,2.5]);cb.outline.set_visible(False);cb.set_label('Средняя потеря / HIST',fontsize=9)
save(fig,'2.4','Матрица относительных потерь исходных процедур','revision25/results/scores.csv','existing','Q — квартальный охват; M2 — первые два месяца. HIST нормирован отдельно в каждой строке.',matrices)
fig,axs=pair(3.8,.25);vals=[]
for ax,h in zip(axs,[1,4]):
    for i,(lab,smp,guard) in enumerate([('Исходная','all','raw'),('Без 2020Q4','omit_2020Q4','raw'),('Ограничение роста','all','clip_g')]):
        z=es[(es.h==h)&(es['sample']==smp)&(es.guard==guard)].set_index('model')
        for off,m,mk in [(-.12,'AR_ESI_EQ_NFCI','o'),(.12,'AR_ESI_EQ_ANFCI','D')]:v=z.loc[m,'ratio_AR_ESI_EQ'];vals.append(v);ax.scatter(v,i+off,s=48,marker=mk,color=C[m],label=m.split('_')[-1]if i==0 else None,zorder=3)
    ax.set_yticks(range(3),['Исходная','Без 2020Q4','Ограничение\nроста']if h==1 else ['']*3);ax.set_ylim(2.5,-.5);ax.axvline(1,color=GRAY,ls='--');ax.set_xlabel('Потеря / AR + ESI + EQ');panel(ax,f'h = {h}');style(ax,'x')
legend(fig,axs[0],2)
save(fig,'2.5','Дополнительность NFCI и ANFCI относительно базы с рынком акций','revision30/results/equity_scores.csv','existing','Сравнения описательные. Небольшой выигрыш относительно собственной базы не означает превосходства над HIST.',vals)

# Information set and main forecast comparisons.
cal=pd.read_csv(R/'revision18/results/forecast_calendar_59.csv');ac=pd.read_csv(R/'revision19/results/ANFCI_calendar_59.csv')
fig,ax=plt.subplots(figsize=(7,3.2));ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
for x,y,w,h,t in [(.02,.66,.30,.23,'Первые два месяца\nESI и охват M2'),(.38,.66,.27,.23,'Конец квартала\nФиксация версий'),(.72,.66,.26,.23,'15-й день\nВыпуск прогноза'),(.12,.12,.34,.25,'Обучение: только цели\nс опубликованным фактом'),(.56,.12,.36,.25,'Позднее: факт ограниченной\nзрелости и оценка качества')]:box(ax,x,y,w,h,t,fs=9.5)
arrow(ax,(.32,.77),(.38,.77));arrow(ax,(.65,.77),(.72,.77));arrow(ax,(.29,.37),(.82,.66));arrow(ax,(.85,.66),(.74,.37))
save(fig,'2.6','Разделение дат наблюдения, фиксации данных, прогноза и оценки','Глава 2, § 2.1–2.2; таблица А.2','c2:2.1','Календарная схема, а не изображение полной оперативной информации аналитика.')
fig,axs=plt.subplots(3,1,figsize=(7,5.5),sharex=True);fig.subplots_adjust(left=.12,right=.98,top=.95,bottom=.09,hspace=.38);dt=dates(cal.origin)
axs[0].plot(dt,cal.gx,color=INK,lw=1.4);axs[0].axhline(0,color=GRAY,lw=.7);axs[0].set_ylabel('Лаговый рост, %')
axs[1].plot(dt,cal.esi,color=TEAL,lw=1.4);axs[1].set_ylabel('ESI, пункты')
axs[2].plot(dt,cal.nfci,color=BLUE,lw=1.5,label='NFCI');axs[2].plot(dt,ac.anfci,color=RED,lw=1.3,label='ANFCI');axs[2].set_ylabel('Индекс США');axs[2].legend(frameon=False,ncol=2)
for ax in axs:style(ax)
ticks(axs[-1],dt)
save(fig,'2.7','Предикторы в исторических информационных наборах','revision18/results/forecast_calendar_59.csv; revision19/results/ANFCI_calendar_59.csv','c2:2.1','Значения доступны на соответствующих прогнозных датах; это последовательность исторических версий, а не одна современная выгрузка.')
fig,axs=pair(4.4,.29);vals=[]
for ax,h in zip(axs,[1,4]):
    z=es[(es.h==h)&(es.guard=='raw')&(es['sample']=='all')].set_index('model');vv=[z.loc[m,'ratio_HIST']for m in ALL];vals+=vv
    ax.barh(range(8),vv,color=[C[m]for m in ALL],height=.57);ax.set_yticks(range(8),[N[m]for m in ALL]if h==1 else ['']*8);ax.invert_yaxis();ax.axvline(1,color=GRAY,ls='--',lw=.8);ax.set_xlim(0,max(vv)*1.25);ax.set_xlabel('Средняя потеря / HIST');panel(ax,f'h = {h}');style(ax,'x')
    for i,v in enumerate(vv):ax.text(v+.035,i,f'{v:.2f}'.replace('.',','),va='center',fontsize=8.5)
save(fig,'2.8','Качество восьми моделей относительно исторического квантиля','revision30/results/equity_scores.csv','c2:2.3','Исходные прогнозы, расширяющееся окно, полная выборка. Меньше единицы — лучше HIST.',vals)
fig,axs=pair(4.4,.29);vals=[]
for ax,h in zip(axs,[1,4]):
    z=es[(es.h==h)&(es.guard=='raw')&(es['sample']=='all')].set_index('model')
    for i,m in enumerate(ALL):v=z.loc[m,'hit_rate']*100;vals.append(v);ax.scatter(v,i,color=C[m],s=45,zorder=3);ax.text(v+1.5,i,f'{v:.1f}'.replace('.',','),va='center',fontsize=8.5)
    ax.axvline(10,color=GRAY,ls='--');ax.set_xlim(0,60);ax.set_yticks(range(8),[N[m]for m in ALL]if h==1 else ['']*8);ax.invert_yaxis();ax.set_xlabel('Частота нарушений, %');panel(ax,f'h = {h}');style(ax,'x')
save(fig,'2.9','Частота случаев роста ниже прогнозируемого десятого процентиля','revision30/results/equity_scores.csv','c2:2.3','Пунктир — номинальные 10%. Частоты описательные и не заменяют проверки условного покрытия.',vals)
d=pd.read_csv(R/'revision29/results/loss_decomposition.csv');fig,axs=pair(3.8,.24);vals=[]
for ax,h in zip(axs,[1,4]):
    z=d[(d.h==h)&(d.variant=='expanding')&(d.config=='Q_raw')].set_index('model').loc[MODS]
    ax.barh(range(5),z.loss_below,color=RED,label='Рост ниже границы');ax.barh(range(5),z.loss_above,left=z.loss_below,color=BLUE,label='Остальные исходы');ax.set_yticks(range(5),[N[m]for m in MODS]if h==1 else ['']*5);ax.invert_yaxis();ax.set_xlabel('Вклад в среднюю потерю');panel(ax,f'h = {h}');style(ax,'x');vals.extend(z[['loss_below','loss_above']].to_numpy().ravel())
legend(fig,axs[0],2)
save(fig,'2.10','Разложение средней квантильной потери по двум типам исходов','revision29/results/loss_decomposition.csv','c2:2.3','Оба компонента имеют общий знаменатель — все прогнозные даты. Их сумма равна средней потере.',vals)

# Historical versus late US index results: same saved procedures as table 2.5.
hist=pd.read_csv(R/'revision19/results/ANFCI_scores.csv')
fig,axs=pair(3.1,.20);vals=[]
for ax,h in zip(axs,[1,4]):
    pairs=[]
    for m in MODS[-2:]:
        q=hist[(hist.h==h)&(hist.variant=='expanding')&(hist.model==m)].set_index('information');pairs.append((q.loc['historical','mean_loss'],q.loc['revised_financial_counterfactual_20261016','mean_loss']))
    for i,((a,z),m)in enumerate(zip(pairs,MODS[-2:])):
        ax.plot([a,z],[i,i],color=C[m],lw=2);ax.scatter(a,i,facecolor='white',edgecolor=C[m],s=60,zorder=3);ax.scatter(z,i,color=C[m],s=45,zorder=3);vals.extend([a,z])
    ax.set_yticks([0,1],['NFCI','ANFCI']if h==1 else ['','']);ax.set_ylim(1.5,-.5);ax.set_xlabel('Средняя квантильная потеря');panel(ax,f'h = {h}');style(ax,'x')
fig.legend(handles=[plt.Line2D([],[],color=GRAY,marker='o',mfc='white',ls='',label='Историческая версия'),plt.Line2D([],[],color=INK,marker='o',ls='',label='Поздняя версия')],loc='upper center',ncol=2,frameon=False,fontsize=9)
save(fig,'2.11','Изменение качества при подстановке поздней истории американских индексов','revision19/results/ANFCI_scores.csv; таблица 2.5','c2:2.4','Поздняя история недоступна исходному прогнозисту. Европейская часть и оценочный факт остаются прежними.',vals)
fig,axs=pair(4.0,.17)
for ax,h in zip(axs,[1,4]):
    z=b[b.h==h].pivot(index='origin',columns='model',values='loss');g=z.AR_ESI-z.AR_ESI_ANFCI;top=g.abs().nlargest(5).index;v=g.loc[top];v=pd.concat([v,pd.Series({'Прочие даты':g.drop(top).sum()})]);ax.barh(range(6),v,color=[BLUE if a>=0 else RED for a in v]);ax.set_yticks(range(6),list(v.index),fontsize=8.5);ax.invert_yaxis();ax.axvline(0,color=GRAY,lw=.8);panel(ax,f'h = {h}');ax.set_xlabel('Вклад в сумму выигрыша ANFCI');style(ax,'x')
save(fig,'2.12','Распределение суммарного выигрыша ANFCI по исходным кварталам','revision25/results/forecasts.csv','c2:2.4','Ориентир — AR + ESI. Показаны пять крупнейших по модулю вкладов и сумма остальных; сумма столбцов равна полному выигрышу.')
fig,axs=pair(3.4,.23)
for ax,h in zip(axs,[1,4]):
    z=b[b.h==h].pivot(index='origin',columns='model',values='loss');vv=[100*(z[m]<z[bm]).mean()for bm in ['AR_ESI','HIST']for m in MODS[-2:]]
    ax.barh(range(4),vv,color=[BLUE,RED,BLUE,RED]);ax.set_yticks(range(4),['NFCI / база','ANFCI / база','NFCI / HIST','ANFCI / HIST']if h==1 else ['']*4);ax.invert_yaxis();ax.set_xlim(0,100);panel(ax,f'h = {h}');ax.set_xlabel('Доля дат с меньшей потерей, %');style(ax,'x')
    for i,v in enumerate(vv):ax.text(v+2,i,f'{v:.1f}'.replace('.',','),va='center',fontsize=9)
save(fig,'2.13','Распространённость выигрыша американских расширений по датам','revision25/results/forecasts.csv','c2:2.3','Частота побед не учитывает величину каждой ошибки и не равна преимуществу по средней потере.')
gg=pd.read_csv(R/'revision25/results/growth_guard.csv');fig,axs=plt.subplots(2,1,figsize=(7,4.4),sharex=True);fig.subplots_adjust(left=.12,right=.98,top=.94,bottom=.11,hspace=.42)
for ax,h in zip(axs,[1,4]):
    z=gg[(gg.variant=='expanding')&(gg.h==h)];dt=dates(z.origin);ax.fill_between(dt,z.minimum,z.maximum,color=PALE,label='Диапазон обучения');ax.plot(dt,z.gx,color=BLUE,lw=1.3,label='Текущий лаговый рост');v=z[z.changed];ax.scatter(dates(v.origin),v.gx,color=RED,s=25,zorder=4,label='Вне диапазона');style(ax);panel(ax,f'h = {h}');ax.set_ylabel('Годовой лог. рост, %')
ticks(axs[-1],dt);legend(fig,axs[0],3)
save(fig,'2.14','Лаговый рост относительно диапазона обучающей выборки','revision25/results/growth_guard.csv','c2:2.4','Диапазон — исторический минимум и максимум допустимых обучающих значений. Он не является доверительным интервалом.')
tr=pd.read_csv(R/'revision25/results/training_checks.csv');fig,ax=plt.subplots(figsize=(7,2.8));fig.subplots_adjust(left=.11,right=.98,top=.84,bottom=.17)
for h,c in [(1,BLUE),(4,RED)]:
    z=tr[(tr.variant=='expanding')&(tr.coverage=='Q')&(tr.h==h)];ax.plot(dates(z.origin),z.n_train,color=c,lw=1.7,label=f'h = {h}')
ax.axhline(52,color=GRAY,ls='--',label='Скользящее окно: 52');style(ax);ticks(ax,dates(z.origin));ax.set_ylabel('Допустимые строки обучения');legend(fig,ax,3)
save(fig,'2.15','Изменение объёма обучения на прогнозных датах','revision25/results/training_checks.csv','c2:2.2','Одна точка соответствует одной прогнозной дате. Горизонты имеют разные ограничения доступности целей.')
mc=pd.read_csv(R/'revision25/results/M2_calendar.csv');fig,ax=plt.subplots(figsize=(7,2.9));fig.subplots_adjust(left=.11,right=.98,top=.84,bottom=.17)
z=mc[mc.series=='nfci'];ax.plot(dates(z.origin),z.quarter_value,color=BLUE,lw=1.4,label='Квартальный охват Q');ax.plot(dates(z.origin),z.value,color=RED,lw=1.3,label='Первые два месяца M2');style(ax);ticks(ax,dates(z.origin));ax.set_ylabel('NFCI, индексные пункты');legend(fig,ax,2)
save(fig,'2.16','Различие квартального и двухмесячного агрегатов NFCI','revision25/results/M2_calendar.csv','c2:2.4','Историческая версия одинакова; меняется охват допустимых недель внутри исходного квартала.')
ph=pd.read_csv(R/'revision29/results/h4_nonoverlap_phases.csv');fig,ax=plt.subplots(figsize=(7,3.5));fig.subplots_adjust(left=.11,right=.98,top=.81,bottom=.17)
for m in ['HIST','AR_ESI','AR_ESI_NFCI','AR_ESI_ANFCI']:
    z=ph[ph.model==m].sort_values('phase');ax.plot(z.phase,z.mean_loss,color=C[m],marker='o',lw=1.5,label=N[m])
ax.set_xticks([1,2,3,4],['Q1','Q2','Q3','Q4']);ax.set_xlabel('Календарный квартал исходных дат');ax.set_ylabel('Средняя потеря при h = 4');style(ax);legend(fig,ax,4)
save(fig,'2.17','Качество годовых прогнозов в группах неперекрывающихся целей','revision29/results/h4_nonoverlap_phases.csv','c2:2.4','Внутри каждой группы цели не перекрываются; группы малы и не являются независимыми повторениями эксперимента.')
bl=pd.read_csv(R/'revision29/results/four_origin_block_omissions.csv');fig,axs=pair(3.7,.12)
for ax,h in zip(axs,[1,4]):
    for m in MODS[-2:]:
        z=bl[(bl.h==h)&(bl.variant=='expanding')&(bl.config=='Q_raw')&(bl.model==m)&(bl.benchmark=='AR_ESI')];ax.plot(dates(z.block_start),z.ratio,color=C[m],lw=1.3,label=m.split('_')[-1])
    ax.axhline(1,color=GRAY,ls='--');style(ax);panel(ax,f'h = {h}');ticks(ax,dates(z.block_start),16);ax.set_ylabel('Потеря / AR + ESI')
legend(fig,axs[0],2)
save(fig,'2.18','Чувствительность выигрыша к исключению четырёх соседних дат','revision29/results/four_origin_block_omissions.csv','c2:2.4','По оси X — начало исключаемого блока. Исключение меняет оценку сохранённых прогнозов, а не обучение моделей.')
inf=pd.read_csv(R/'revision25/results/rolling52_inference.csv');fig,axs=pair(4.9,.28)
for ax,h in zip(axs,[1,4]):
    z=inf[(inf.h==h)&(inf.config=='Q_raw')&(inf.L==4)&(inf.benchmark.isin(['AR_ESI','HIST']))].copy();z=z.sort_values(['benchmark','model']);labs=[]
    for i,row in enumerate(z.itertuples()):
        c=C[row.model];ax.plot([row.lo_family95,row.hi_family95],[i,i],color=c,alpha=.3,lw=4);ax.plot([row.lo95,row.hi95],[i,i],color=c,lw=1.2);ax.scatter(row.difference,i,color=c,s=28,zorder=3);labs.append(row.model.replace('AR_ESI_','')+' / '+('база'if row.benchmark=='AR_ESI'else'HIST'))
    ax.axvline(0,color=GRAY,ls='--');ax.set_yticks(range(len(z)),labs if h==1 else ['']*len(z),fontsize=9);ax.invert_yaxis();ax.set_xlabel('Разность средних потерь');panel(ax,f'h = {h}');style(ax,'x')
save(fig,'2.19','Неопределённость сравнений в скользящем окне из 52 наблюдений','revision25/results/rolling52_inference.csv','c2:2.4','Q_raw, HAC L=4. Тонкие линии — обычные 95%-е интервалы; широкие светлые — одновременные интервалы семьи из 20 сравнений. Это не интервалы основной расширяющейся процедуры.')

# Recommendation chapter: original workflow, case cards, and a model review scheme.
fig,ax=plt.subplots(figsize=(7,6));ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
items=[(.75,'Фиксация даты и исторических версий'),(.57,'Проверка полноты и общих дат'),(.39,'Прогнозы ориентиров и расширений'),(.21,'Диагностика экстраполяции и пояснения'),(.03,'Архив выпуска и последующая оценка')]
for y,t in items:box(ax,.20,y,.75,.12,t,fs=10)
for k in range(4):arrow(ax,(.575,items[k][0]),(.575,items[k+1][0]+.12))
box(ax,.015,.58,.13,.22,'Пропуск:\nпроверить\nисточник',fs=9);arrow(ax,(.20,.63),(.145,.69));arrow(ax,(.08,.58),(.20,.45))
box(ax,.015,.20,.13,.22,'Необычный\nрост:\nпроверить\nпрогноз',fs=8.5);arrow(ax,(.20,.27),(.145,.31));arrow(ax,(.08,.20),(.20,.09))
save(fig,'3.1','Порядок формирования и последующей проверки квартальной оценки рисков роста','Глава 3, § 3.2; исходная схема мониторинга','existing','Пропуски не заменяются нулями; исходные прогнозы сохраняются вместе с диагностикой.')
for key,origin,title in [('3.2','2020Q4','Прогнозы в реконструированном выпуске от 15 января 2021 года'),('3.3','2024Q4','Прогнозы в реконструированном выпуске от 15 января 2025 года')]:
    fig,axs=pair(3.8,.24)
    for ax,h in zip(axs,[1,4]):
        z=f[(f.variant=='expanding')&(f.origin==origin)&(f.h==h)&f.config.isin(['Q_raw','Q_clip_g'])]
        for off,cfg,mk in [(-.12,'Q_raw','o'),(.12,'Q_clip_g','D')]:
            q=z[z.config==cfg].set_index('model')
            for i,m in enumerate(MODS):ax.scatter(q.loc[m,'forecast'],i+off,marker=mk,color=C[m],s=40,zorder=3)
        actual=z.actual.iloc[0];ax.axvline(actual,color='black',ls='--',lw=1,label='Последующий факт');ax.axvline(0,color=GRAY,lw=.7);ax.set_yticks(range(5),[N[m]for m in MODS]if h==1 else ['']*5);ax.invert_yaxis();ax.set_xlabel('Годовой лог. рост, %');panel(ax,f'h = {h}');style(ax,'x')
    fig.legend(handles=[plt.Line2D([],[],color=INK,marker='o',ls='',label='Исходный прогноз'),plt.Line2D([],[],color=INK,marker='D',ls='',label='Ограничение роста'),plt.Line2D([],[],color='black',ls='--',label='Последующий факт')],loc='upper center',ncol=3,frameon=False,fontsize=8.5)
    save(fig,key,title,'revision25/results/forecasts.csv; chapter3/evidence/case_inputs.csv','c3:cases','Факт показан для последующей оценки; он не был известен на дату выпуска. Это иллюстрация, входящая в основную выборку.')
fig,ax=plt.subplots(figsize=(7,4.8));ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
box(ax,.21,.80,.58,.15,'Появилось улучшение средней потери');box(ax,.02,.49,.43,.18,'Проверить ориентир, версии\nи концентрацию на отдельных датах',fs=9.5);box(ax,.55,.49,.43,.18,'Проверить нарушения\nи неопределённость сравнения',fs=9.5)
arrow(ax,(.50,.80),(.24,.67));arrow(ax,(.50,.80),(.76,.67));box(ax,.21,.20,.58,.15,'Сохранить исходную и новую процедуры');arrow(ax,(.24,.49),(.50,.35));arrow(ax,(.76,.49),(.50,.35));box(ax,.21,.01,.58,.11,'Оценивать на новых прогнозных датах');arrow(ax,(.50,.20),(.50,.12))
save(fig,'3.4','Основания для проверки и пересмотра прогнозной процедуры','Глава 3, § 3.3; таблица 3.5','c3:end','Схема рекомендуемых действий. Её внедрение и экономическая эффективность в работе не проверялись.')

# Two detailed diagnostic figures in the appendix.
ep=pd.read_csv(R/'revision25/results/episode_scores.csv');fig,axs=pair(3.9,.18)
episodes=['pre2020','covid_overlap','2022_2025'];present=ep.episode.unique().tolist();episodes=[v for v in episodes if v in present]
if len(episodes)!=3:episodes=present
for ax,h in zip(axs,[1,4]):
    z=ep[(ep.h==h)&(ep.config=='Q_raw')&(ep.variant=='expanding')];m=[]
    for per in episodes:
        q=z[z.episode==per].set_index('model');m.append([q.loc[mo,'mean_loss']/q.loc['HIST','mean_loss']for mo in MODS])
    m=np.array(m).T;im=ax.imshow(m,cmap=colors.LinearSegmentedColormap.from_list('seq',['#F4F6FA',BLUE]),aspect='auto',vmin=0,vmax=max(3,m.max()));ax.set_yticks(range(5),[N[mo]for mo in MODS]if h==1 else ['']*5);ax.set_xticks(range(len(episodes)),[{'pre2020':'До 2020','covid_overlap':'Пандемийные цели','pandemic':'Пандемия','2020_2021':'2020–2021','2022_2025':'2022–2025'}.get(v,v)for v in episodes],rotation=25,ha='right',fontsize=8.5);panel(ax,f'h = {h}');ax.tick_params(length=0)
    for i,j in np.ndindex(m.shape):ax.text(j,i,f'{m[i,j]:.2f}'.replace('.',','),ha='center',va='center',fontsize=9,color='white'if m[i,j]>max(3,m.max())*.55 else INK)
save(fig,'Б.1','Относительные потери на отдельных исторических отрезках','revision25/results/episode_scores.csv','app:end','Каждая ячейка нормирована на HIST того же периода. Короткие подвыборки имеют описательный статус.')
co=pd.read_csv(R/'revision29/results/common_origins_scores.csv');fig,axs=pair(3.9,.23)
for ax,h in zip(axs,[1,4]):
    z=co[(co.h==h)&(co.variant=='expanding')&(co.config=='Q_raw')].set_index('model').loc[MODS];v=z.mean_loss/z.loc['HIST','mean_loss'];ax.barh(range(5),v,color=[C[mo]for mo in MODS]);ax.set_yticks(range(5),[N[mo]for mo in MODS]if h==1 else ['']*5);ax.invert_yaxis();ax.axvline(1,color=GRAY,ls='--');ax.set_xlabel('Средняя потеря / HIST');panel(ax,f'h = {h}');style(ax,'x')
save(fig,'Б.2','Сравнение горизонтов на 55 общих исходных датах','revision29/results/common_origins_scores.csv','app:end','Состав исходных дат одинаков для двух горизонтов; сами целевые интервалы и обучающие выборки различаются.')
assert len(manifest)==27,len(manifest)
(W/'visual_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('Created',len(manifest),'logical figures; global titles and source text remain outside images.')
